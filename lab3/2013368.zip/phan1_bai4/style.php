<?php 
    header("content-type: text/css");
?>

td {
    text-align: center;
    width: 40px;
    height: 30px;
}
table
{
	background-color: yellow;
}
table, td {
	border: 2px solid black;
	border-collapse: collapse;
}
div{
	margin-left:20%;
}